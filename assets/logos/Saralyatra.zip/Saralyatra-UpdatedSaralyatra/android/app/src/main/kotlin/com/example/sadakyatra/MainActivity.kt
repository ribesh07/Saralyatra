package com.example.saralyatra

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
