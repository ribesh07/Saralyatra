#import <Flutter/Flutter.h>

@interface EsewaFlutterSdkPlugin : NSObject<FlutterPlugin>
@end
