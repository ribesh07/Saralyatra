const String ARGS_KEY_CONFIG = 'config';
const String ARGS_KEY_PAYMENT = 'payment';
const String METHOD_CHANNEL_NAME = 'flutter_sdk_channel';
const String PAYMENT_METHOD_SUCCESS = 'payment_success';
const String PAYMENT_METHOD_FAILURE = 'payment_failure';
const String PAYMENT_METHOD_CANCELLATION = 'payment_cancellation';