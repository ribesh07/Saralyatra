class EsewaPaymentFailure{

  final String errorMsg;

  EsewaPaymentFailure({required this.errorMsg});

}