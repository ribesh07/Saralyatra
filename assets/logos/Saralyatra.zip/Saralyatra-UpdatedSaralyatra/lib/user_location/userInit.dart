// ignore_for_file: file_names

import 'package:flutter/material.dart';
import 'package:saralyatra/user_location/usercard/usercard.dart';

class Usercard extends StatelessWidget {
  const Usercard({super.key});

  @override
  Widget build(BuildContext context) {
    return UserCardApp();
  }
}
